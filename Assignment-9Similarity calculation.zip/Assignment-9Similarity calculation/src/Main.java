import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

class WordProcessor {
    private Set<String> distinctWords;

    public WordProcessor() {
        distinctWords = new HashSet<>();
    }

    public void readFile(String filePath) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Split the line into words using space as the delimiter
                String[] words = line.split("\\s+");
                // Add each word to the set of distinct words
                for (String word : words) {
                    distinctWords.add(word.toLowerCase()); // Convert to lowercase for case-insensitive comparison
                }
            }
        }
    }

    public Set<String> getDistinctWords() {
        return distinctWords;
    }
}

class SimilarityCalculator {
    public double calculateSimilarity(Set<String> set1, Set<String> set2) {
        Set<String> union = new HashSet<>(set1);
        union.addAll(set2);

        Set<String> intersection = new HashSet<>(set1);
        intersection.retainAll(set2);

        // Jaccard Similarity Coefficient
        double jaccardSimilarity = (double) intersection.size() / union.size();
        return jaccardSimilarity;
    }
}

public class MainProgram {
    public static void main(String[] args) {
        try {
            // Instantiate WordProcessor and SimilarityCalculator
            WordProcessor wordProcessor = new WordProcessor();
            SimilarityCalculator similarityCalculator = new SimilarityCalculator();

            // Read text from two different files
            wordProcessor.readFile("file1.txt");
            Set<String> set1 = wordProcessor.getDistinctWords();

            wordProcessor.readFile("file2.txt");
            Set<String> set2 = wordProcessor.getDistinctWords();

            // Calculate and display the Jaccard similarity coefficient
            double similarity = similarityCalculator.calculateSimilarity(set1, set2);
            System.out.println("Jaccard Similarity Coefficient: " + similarity);

        } catch (IOException e) {
            System.out.println("An error occurred while reading the files: " + e.getMessage());
        }
    }
}
